import os
import pprint
import socket

execfile('/home/hcgroup/hxg/query_info.py')

HxG = {
	'hxg_partition'              : 'yes', # This has to be 'yes' always, regardless of partitioning
#	'non_default_core_node_list' : [252, 251, 170, 169, 171, 175, 176, 253, 254, 262, 193],
#	'non_default_core_node_list' : [ 171, 175, 176, 253, 254, 262, 193],
	'default_core_type'          : 'gpu',
#	'hxg_partition_lists'        : [([190],[62, 118, 103, 71, 81, 98])] # for TPC-H Q1
#       'hxg_partition_lists'        : [([282],[23]), ([313],[215, 308])]   # for TPC-H Q9
#	'hxg_partition_lists'        : [([50],[94]), ([20, 99],[81])]       # for TPC-H Q4
#	'hxg_partition_lists'        : [([18], [287]), ([272, 271, 44, 100], [193])]       # for TPC-H Q21
}
 
if query == 'q1':
	HxG['hxg_partition_lists'] = [([190],[62, 118, 103, 71, 81, 98])] 
elif query == 'q9':
	HxG['hxg_partition_lists'] = [([282],[23]), ([313],[215, 308])] 
elif query == 'q4':
	HxG['hxg_partition_lists'] = [([50],[94]), ([20, 99],[81])] 
elif query == 'q21':
	HxG['hxg_partition_lists'] = [([18], [287]), ([272, 271, 44, 100], [193])]
else:
	print 'ERROR UNKNOWN QUERY',query
	os.exit(-1) 

Preprocessing = {
	'db_name' : 'tpch-sf-1',
#	'db_name' : 'tpch-sf-1',
#	'db_name' : 'tpch-sf-1',
	'dbms_hostname' : "localhost",
	'dbms_port' : 50000,
	'dump_pp_file' : os.environ['HOME'] + '/.hxg/preprocessing/pp_dump',
#	'dump_pp_file' : os.environ['HOME'] + '/debug/pp_dump',
}

def repeat(n, what):
	r = []
	for i in range(0,n):
		r += [what]
	return r

# Type of run
run_type = run
#run_type = 'cpu_unpartitioned'
#run_type = 'cpu_2_parts'
#run_type = 'gpu_unpartitioned'
#run_type = 'cpu_partitioned'
#run_type = 'gpu_partitioned'
#run_type = 'mixed'

#print "run_type = ", run_type

host = socket.gethostname()
#host = 'verdi'

hyperthreads = 2 # the number of threads a CPU core cat sort-of-handle simultaneously
io_threads = 1

if host == 'verdi':
	cpu_sockets       = 2
	cores_per_socket  = 8
	#change only this for testing verdi on 1 core
	gpu_cores         = 2
else:
	cores_per_socket  = 6
	gpu_cores         = 1
	cpu_sockets       = 1

#amount of work to give to cpu, rest will go to gpu
#used only in mixed mode
#these are the two main parameters
#pin_cpu_parts_per_socket = 4


#expected gpu speedup over cpu (when accounting for I/O to and from the GPU)
cpu_gpu_imbalance = 5.0 / 3.0
cpu_gpu_balance = 1.0 / ((gpu_cores + 1) * cpu_gpu_imbalance)


if run_type == 'gpu_unpartitioned':
	partition_map_cpu_sockets  = 0
	gpu_threads                = 2
	gpu_parts                  = 1
	cpu_workers_per_socket     = cores_per_socket - (gpu_threads * gpu_parts)
	core_type                  = 'gpu'
	cpu_parts_per_socket       = 0
	cores_per_socket           = 0

if run_type == 'gpu_partitioned':
	partition_map_cpu_sockets  = 0
	gpu_threads                = 2
	gpu_parts                  = gpu_cores
	cpu_workers_per_socket     = cores_per_socket - (gpu_threads * gpu_parts)
	core_type                  = 'gpu'
	cpu_parts_per_socket       = 0
	cores_per_socket           = 0

if run_type == 'cpu_partitioned' :
	partition_map_cpu_sockets  = 1
	gpu_cores                  = 0
	gpu_threads                = 0
	gpu_parts                  = 0
	core_type                  = 'cpu'
	cpu_workers_per_socket     = cores_per_socket * hyperthreads * cpu_sockets
	cpu_parts_per_socket       = cpu_workers_per_socket

if run_type == 'cpu_unpartitioned' : # note that, for simplicity, we also restrict ourselves here to one socket
	partition_map_cpu_sockets  = 1
	gpu_cores                  = 0
	gpu_threads                = 0
	gpu_parts                  = 0
	core_type                  = 'cpu'
	cpu_workers_per_socket     = cores_per_socket * hyperthreads 
	cpu_parts_per_socket       = 1

if run_type == 'cpu_2_parts' : # note that, for simplicity, we also restrict ourselves here to one socket
	partition_map_cpu_sockets  = 1
	gpu_cores                  = 0
	gpu_threads                = 0
	gpu_parts                  = 0
	core_type                  = 'cpu'
	cpu_workers_per_socket     = cores_per_socket * hyperthreads 
	cpu_parts_per_socket       = 2

if run_type == "mixed" :
	gpu_threads                = 1 # why?
	gpu_parts                  = gpu_cores
	core_type                  = 'gpu'
	if cpu_sockets > 1:
		partition_map_cpu_sockets = cpu_sockets - 1
		cpu_workers_per_socket = cores_per_socket 
	else:
		partition_map_cpu_sockets = 1
		cpu_workers_per_socket = cores_per_socket  - (gpu_threads * gpu_parts)
		assert(cpu_workers_per_socket > 0)
	cpu_parts_per_socket       = cpu_workers_per_socket # one partition here per worker thread

processing_share = 1/3.0
#print "total_parts = ", total_parts
#print "processing_share = ", processing_share
# {device manager : { local id : (num of partitions, number of threads/streams, portion of data) }}
control_device = ('HostDeviceManager' ,0)
# The following assumes gpu_parts <= 2 and cpu_sockets <= 2
partition_map = {}
if gpu_parts > 0:
	partition_map['CudaDeviceManager'] = {0 : (1, gpu_threads, processing_share)}
	if gpu_parts > 1:
		partition_map['CudaDeviceManager'].update({1 : (1, gpu_threads, processing_share)})

if cpu_parts_per_socket > 0:
	partition_map['HostDeviceManager'] = {0 : (cpu_parts_per_socket, cpu_workers_per_socket, processing_share)}
	if partition_map_cpu_sockets == 2:
		partition_map['HostDeviceManager'].update({1 : (cpu_parts_per_socket, cpu_workers_per_socket, processing_share)})
	if gpu_parts > 1:
		if cpu_sockets == 2:
			control_device = ('HostDeviceManager' , 1)

num_of_active_processors = 0
for x in partition_map.values():
	num_of_active_processors += len(x)

#########print 'num_of_active_processors',num_of_active_processors
assert(num_of_active_processors)

balance = []

for i in partition_map.values():
	for j in i.values():
		for k in range(0,j[0]):
			#balance += [j[2]/j[0]]
			balance += [1.0/num_of_active_processors/j[0]]


#print 'sum balance ', sum(balance)
assert(sum(balance) == 1.0)
total_parts = gpu_parts + cpu_parts_per_socket * partition_map_cpu_sockets
assert(len(balance) == total_parts)

Axe = {
	'scheduler'	     : 'AsyncScheduler',
	#'print_final_graph'  : True,
	'partition_balance'  : balance,
	'control_device'     : control_device,
	'partition_map'      : partition_map,
#	'buffers_to_print'   : ['mInputBuffer','mIntBuffer_0', 'mIntBuffer_1', 'mIntBuffer_2' ]
#	'default_cpu_socket' : 1
}

ResourceTree = {
	'schedulers'    : ['SyncScheduler','AsyncScheduler'],
	'plan_libs'     : [os.environ['AXE_WB_DIR'] + '/lib/libplans.so'],
	'function_libs' : [os.environ['AXE_WB_DIR'] + '/lib/libFunctions.so']
}


cuda_exists = os.path.isdir('/usr/local/cuda')

#list .so files name
device_lib_names = ['HostDeviceManager', 'cpu_op_store']
#device_lib_names = [ 'cpu_op_store']

if cuda_exists:
	device_lib_names += ['CudaDeviceManager', 'cuda_op_store', 'nvprof_profiler']

Dal = {
	#this opens all the .so files and loads their registered classes into the factory
	"libraries" : [os.environ['AXE_WB_DIR'] + '/lib/lib' + x + '.so' for x in device_lib_names],
	#"device_managers" : ['CudaDeviceManager','HostDeviceManager'],
}
	
wax = {
	'plan_libs' : [os.environ['AXE_WB_DIR'] + '/lib/libplans.so']
}


HostDeviceManager = {
	"op_stores_classes" : ["CPUOperationStore"],
}
CudaDeviceManager = {
	"op_stores_classes" : ["CUDAOperationStore"],
}


#try to do this with your xml,json or ini file!!!
#
pp = pprint.PrettyPrinter()
pp.pprint(Axe)

# Fixme: Right now this does nothing
if 'gpu_parts' in Axe:
	if Axe['gpu_parts'] == 0: 
		assert(Axe['gpu_threads'] == 0 and Axe['core_type'] == 'cpu')
	else:
		assert (Axe['core_type'] == 'gpu')



